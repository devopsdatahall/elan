<?php
/*
@elanRef: @block_elan/block.php
*/

defined('MOODLE_INTERNAL') || die();

// print_object($this);
$elanBlockType = $this->instance->blockname;

$elanCollectionFullwidthTop =  array(
  "elan_feedback",
);

$elanCollectionAboveContent =  array(
  "elan_contact_form",
);

$elanCollectionBelowContent =  array(
  "elan_course_rating",
  "elan_more_courses",
  "elan_course_instructor",
);

$elanCollection = array_merge($elanCollectionFullwidthTop, $elanCollectionAboveContent, $elanCollectionBelowContent);

if (empty($this->config)) {
  if(in_array($elanBlockType, $elanCollectionFullwidthTop)) {
    $this->instance->defaultregion = 'fullwidth-top';
    $this->instance->region = 'fullwidth-top';
    $DB->update_record('block_instances', $this->instance);
  }
  if(in_array($elanBlockType, $elanCollectionAboveContent)) {
    $this->instance->defaultregion = 'above-content';
    $this->instance->region = 'above-content';
    $DB->update_record('block_instances', $this->instance);
  }
  if(in_array($elanBlockType, $elanCollectionBelowContent)) {
    $this->instance->defaultregion = 'below-content';
    $this->instance->region = 'below-content';
    $DB->update_record('block_instances', $this->instance);
  }
}
