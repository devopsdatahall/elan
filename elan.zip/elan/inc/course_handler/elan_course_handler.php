<?php
/*
* COURSE HANDLER
*/

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot. '/course/renderer.php');
include_once($CFG->dirroot . '/course/lib.php');

class elanCourseHandler {
    public function elanGetCourseDetails($courseId) {
        global $CFG, $COURSE, $USER, $DB, $SESSION, $SITE, $PAGE, $OUTPUT;


        $courseId = (int)$courseId;
        if ($DB->record_exists('course', array('id' => $courseId))) {
        // @elanComm: Initiate
        $elanCourse = new \stdClass();
        $chelper = new coursecat_helper();
        $courseContext = context_course::instance($courseId);

        $courseRecord = $DB->get_record('course', array('id' => $courseId));
        $courseElement = new core_course_list_element($courseRecord);

        /* @elanBreak */
        $courseId = $courseRecord->id;
        $courseShortName = $courseRecord->shortname;
        $courseFullName = $courseRecord->fullname;
        $courseSummary = $chelper->get_course_formatted_summary($courseElement, array('noclean' => true, 'para' => false));
        $courseFormat = $courseRecord->format;
        $courseAnnouncements = $courseRecord->newsitems;
        $courseStartDate = $courseRecord->startdate;
        $courseEndDate = $courseRecord->enddate;
        $courseVisible = $courseRecord->visible;
        $courseCreated = $courseRecord->timecreated;
        $courseUpdated = $courseRecord->timemodified;
        $courseRequested = $courseRecord->requested;
        $courseEnrolmentCount = count_enrolled_users($courseContext);
        $course_is_enrolled = is_enrolled($courseContext, $USER->id, '', true);

        /* @elanBreak */
        $categoryId = $courseRecord->category;

        try {
            $courseCategory = core_course_category::get($categoryId);
            $categoryName = $courseCategory->get_formatted_name();
            $categoryUrl = $CFG->wwwroot . '/course/index.php?categoryid='.$categoryId;
        } catch (Exception $e) {
            $courseCategory = "";
            $categoryName = "";
            $categoryUrl = "";
        }

        /* @elanBreak */
        $enrolmentLink = $CFG->wwwroot . '/enrol/index.php?id=' . $courseId;
        $courseUrl = new moodle_url('/course/view.php', array('id' => $courseId));
        // @elanComm: Start Payment
        $enrolInstances = enrol_get_instances($courseId, true);

        $course_price = '';
        $course_currency = '';
        foreach($enrolInstances as $singleenrolInstances){
          if($singleenrolInstances->enrol == 'paypal'){
              $course_price = $singleenrolInstances->cost;
              $course_currency = $singleenrolInstances->currency;
          }else{
              $course_price = '';
              $course_currency = '';
          }
        }
        

        $elanArrayOfCosts = array();
            $elanCourseContacts = array();
            if ($courseElement->has_course_contacts()) {
                foreach ($courseElement->get_course_contacts() as $key => $courseContact) {
                $elanCourseContacts[$key] = new \stdClass();
                $elanCourseContacts[$key]->userId = $courseContact['user']->id;
                $elanCourseContacts[$key]->username = $courseContact['user']->username;
                $elanCourseContacts[$key]->name = $courseContact['user']->firstname . ' ' . $courseContact['user']->lastname;
                $elanCourseContacts[$key]->role = $courseContact['role']->displayname;
                $elanCourseContacts[$key]->profileUrl = new moodle_url('/user/view.php', array('id' => $courseContact['user']->id, 'course' => SITEID));
                }
            }


        // @elanComm: Process first image
        $contentimages = $contentfiles = $CFG->wwwroot . '/theme/elan/images/elanBg.png';
        foreach ($courseElement->get_course_overviewfiles() as $file) {
            $isimage = $file->is_valid_image();
            $url = file_encode_url("{$CFG->wwwroot}/pluginfile.php",
                    '/'. $file->get_contextid(). '/'. $file->get_component(). '/'.
                    $file->get_filearea(). $file->get_filepath(). $file->get_filename(), !$isimage);
            if ($isimage) {
                $contentimages = $url;
            } else {
                $contentfiles = $CFG->wwwroot . '/theme/elan/images/elanBg.png';
            }
        }

        /* Map data */
        $elanCourse->courseId = $courseId;
        $elanCourse->enrolments = $courseEnrolmentCount;
        $elanCourse->categoryId = $categoryId;
        $elanCourse->categoryName = $categoryName;
        $elanCourse->categoryUrl = $categoryUrl;
        $elanCourse->shortName = $courseShortName;
        $elanCourse->fullName = format_text($courseFullName, FORMAT_HTML, array('filter' => true));
        $elanCourse->summary = $courseSummary;
        $elanCourse->imageUrl = $contentimages;
        $elanCourse->format = $courseFormat;
        $elanCourse->announcements = $courseAnnouncements;
        $elanCourse->startDate = userdate($courseStartDate, get_string('strftimedatefullshort', 'langconfig'));
        $elanCourse->endDate = userdate($courseEndDate, get_string('strftimedatefullshort', 'langconfig'));
        $elanCourse->visible = $courseVisible;
        $elanCourse->created = userdate($courseCreated, get_string('strftimedatefullshort', 'langconfig'));
        $elanCourse->updated = userdate($courseUpdated, get_string('strftimedatefullshort', 'langconfig'));
        $elanCourse->requested = $courseRequested;
        $elanCourse->enrolmentLink = $enrolmentLink;
        $elanCourse->url = $courseUrl;
        $elanCourse->teachers = $elanCourseContacts;
        $elanCourse->course_price = $course_price;
        $elanCourse->course_currency = $course_currency;
        $elanCourse->course_is_enrolled = $course_is_enrolled;

        /* Render object */
        $elanRender = new \stdClass();
        $elanRender->enrolmentIcon = '';
        $elanRender->enrolmentIcon1 = '';
        $elanRender->announcementsIcon     =     '';
        $elanRender->announcementsIcon1     =     '';
        $elanRender->updatedDate           =     '';
        $elanRender->updatedDate         =     userdate($courseUpdated, get_string('strftimedatefullshort', 'langconfig'));
        $elanRender->title             =     '<h3><a href="'. $elanCourse->url .'">'. $elanCourse->fullName .'</a></h3>';
        $elanRender->coverImage        =     '<img class="img-whp" src="'. $contentimages .'" alt="'.$elanCourse->fullName.'">';
        $elanRender->ImageUrl = $contentimages;
        /* @elanBreak */
        $elanCourse->elanRender = $elanRender;
        return $elanCourse;
        }
        return null;
    }

    public function elanGetCourseDescription($courseId, $maxLength){
        global $CFG, $COURSE, $USER, $DB, $SESSION, $SITE, $PAGE, $OUTPUT;
    
        if ($DB->record_exists('course', array('id' => $courseId))) {
        $chelper = new coursecat_helper();
        $courseContext = context_course::instance($courseId);
    
        $courseRecord = $DB->get_record('course', array('id' => $courseId));
        $courseElement = new core_course_list_element($courseRecord);
    
        if ($courseElement->has_summary()) {
            $courseSummary = $chelper->get_course_formatted_summary($courseElement, array('noclean' => false, 'para' => false));
            if($maxLength != null) {
            if (strlen($courseSummary) > $maxLength) {
                $courseSummary = wordwrap($courseSummary, $maxLength);
                $courseSummary = substr($courseSummary, 0, strpos($courseSummary, "\n")) . '...';
            }
            }
            return $courseSummary;
        }
    
        }
        return null;
    }

    public function elanListCategories(){
        global $DB, $CFG;
        $topcategory = core_course_category::top();
        $topcategorykids = $topcategory->get_children();
        $areanames = array();
        foreach ($topcategorykids as $areaid => $topcategorykids) {
            $areanames[$areaid] = $topcategorykids->get_formatted_name();
            foreach($topcategorykids->get_children() as $k=>$child){
                $areanames[$k] = $child->get_formatted_name();
            }
        }
        return $areanames;
    }

    public function elanGetCategoryDetails($categoryId){
        global $CFG, $COURSE, $USER, $DB, $SESSION, $SITE, $PAGE, $OUTPUT;
    
        if ($DB->record_exists('course_categories', array('id' => $categoryId))) {
    
          $categoryRecord = $DB->get_record('course_categories', array('id' => $categoryId));
    
          $chelper = new coursecat_helper();
          $categoryObject = core_course_category::get($categoryId);
    
          $elanCategory = new \stdClass();
    
          $categoryId = $categoryRecord->id;
          $categoryName = format_text($categoryRecord->name, FORMAT_HTML, array('filter' => true));
          $categoryDescription = $chelper->get_category_formatted_description($categoryObject);
    
          $categorySummary = format_string($categoryRecord->description, $striplinks = true,$options = null);
          $isVisible = $categoryRecord->visible;
          $categoryUrl = $CFG->wwwroot . '/course/index.php?categoryid=' . $categoryId;
          $categoryCourses = $categoryObject->get_courses();
          $categoryCoursesCount = count($categoryCourses);
    
          $categoryGetSubcategories = [];
          $categorySubcategories = [];
          if (!$chelper->get_categories_display_option('nodisplay')) {
            $categoryGetSubcategories = $categoryObject->get_children($chelper->get_categories_display_options());
          }
          foreach($categoryGetSubcategories as $k=>$elanSubcategory) {
            $elanSubcat = new \stdClass();
            $elanSubcat->id = $elanSubcategory->id;
            $elanSubcat->name = $elanSubcategory->name;
            $elanSubcat->description = $elanSubcategory->description;
            $elanSubcat->depth = $elanSubcategory->depth;
            $elanSubcat->coursecount = $elanSubcategory->coursecount;
            $categorySubcategories[$elanSubcategory->id] = $elanSubcat;
          }
    
          $categorySubcategoriesCount = count($categorySubcategories);
    
          /* Do image */
          $outputimage = '';
          //elanComm: Fetching the image manually added to the coursecat description via the editor.
          $description = $chelper->get_category_formatted_description($categoryObject);
          $src = "";
          if ($description) {
            $dom = new DOMDocument();
            $dom->loadHTML($description);
            $xpath = new DOMXPath($dom);
            $src = $xpath->evaluate("string(//img/@src)");
          }
          if ($src && $description){
            $outputimage = $src;
          } else {
            foreach($categoryCourses as $child_course) {
              if ($child_course === reset($categoryCourses)) {
                foreach ($child_course->get_course_overviewfiles() as $file) {
                  if ($file->is_valid_image()) {
                    $imagepath = '/' . $file->get_contextid() . '/' . $file->get_component() . '/' . $file->get_filearea() . $file->get_filepath() . $file->get_filename();
                    $imageurl = file_encode_url($CFG->wwwroot . '/pluginfile.php', $imagepath, false);
                    $outputimage  =  $imageurl;
                    // Use the first image found.
                    break;
                  }
                }
              }
            }
          }
    
          /* Map data */
          $elanCategory->categoryId = $categoryId;
          $elanCategory->categoryName = $categoryName;
          $elanCategory->categoryDescription = $categoryDescription;
          $elanCategory->categorySummary = $categorySummary;
          $elanCategory->isVisible = $isVisible;
          $elanCategory->categoryUrl = $categoryUrl;
          $elanCategory->coverImage = $outputimage;
          $elanCategory->ImageUrl = $outputimage;
          $elanCategory->courses = $categoryCourses;
          $elanCategory->coursesCount = $categoryCoursesCount;
          $elanCategory->subcategories = $categorySubcategories;
          $elanCategory->subcategoriesCount = $categorySubcategoriesCount;
          return $elanCategory;
    
        }
      }

    public function elanGetExampleCategories($maxNum) {
        global $CFG, $DB;
    
        $elanCategories = $DB->get_records('course_categories', array(), $sort='', $fields='*', $limitfrom=0, $limitnum=$maxNum);
    
        $elanReturn = array();
        foreach ($elanCategories as $elanCategory) {
        $elanReturn[] = $this->elanGetCategoryDetails($elanCategory->id);
        }
        return $elanReturn;
    }

    public function elanGetExampleCategoriesIds($maxNum) {
        global $CFG, $DB;
    
        $elanCategories = $this->elanGetExampleCategories($maxNum);
    
        $elanReturn = array();
        foreach ($elanCategories as $key => $elanCategory) {
          $elanReturn[] = $elanCategory->categoryId;
        }
        return $elanReturn;
      }
}
