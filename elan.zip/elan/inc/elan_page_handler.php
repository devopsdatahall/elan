<?php
/*
@elanRef: @
*/

defined('MOODLE_INTERNAL') || die();
include_once($CFG->dirroot . '/course/lib.php');

class elanPageHandler {
  public function elanGetPageTitle() {
    global $PAGE, $COURSE, $DB, $CFG;

    $elanReturn = $PAGE->heading;

    if(
      $DB->record_exists('course', array('id' => $COURSE->id))
      && $COURSE->format == 'site'
      && $PAGE->cm
      && $PAGE->cm->name !== NULL
    ){
      $elanReturn = $PAGE->cm->name;
    } elseif($PAGE->pagetype == 'blog-index') {
      $elanReturn = get_string("blog", "blog");
    }

    return $elanReturn;
  }
}
