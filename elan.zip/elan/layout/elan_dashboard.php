<?php
defined('MOODLE_INTERNAL') || die();
echo $OUTPUT->doctype();

include($CFG->dirroot . '/theme/elan/inc/elan_themehandler.php');

$bodyattributes = $OUTPUT->body_attributes();
include($CFG->dirroot . '/theme/elan/inc/elan_themehandler_context.php');

echo $OUTPUT->render_from_template('theme_elan/elan_dashboard', $templatecontext);